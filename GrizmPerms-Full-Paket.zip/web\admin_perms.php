<?php
/**
 * GrizmMC Network - Rol, İzin, VIP Mağaza & Cüzdan Yönetim Merkezi (GrizmPerms Web Admin)
 */

require_once __DIR__ . '/config.php';

if (!is_staff_user()) {
    header('Location: login.php?redirect=admin_perms.php');
    exit;
}

$pageTitle = "Rol, İzin & VIP Yönetimi";
$activePage = "admin_perms";
$isUnlocked = !empty($_SESSION['server_panel_unlocked']);
$syncMeta = gperm_get_sync_meta();

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<main class="admin-panel-wrapper">
  <div class="container">

    <!-- Üst Başlık & Aksiyonlar -->
    <div class="admin-header-row">
      <div class="admin-title-group">
        <div class="admin-badge">
          <i class="fa-solid fa-crown"></i>
          <span>GRIZMPERMS CENTRAL ENGINE</span>
        </div>
        <h1 class="admin-title">Rol, İzin & VIP Yönetim Merkezi</h1>
        <p class="admin-subtitle">
          Lobi, TekBlok SkyBlock, Towny SMP ve PvP sunucularındaki tüm rütbeleri, izin ağacını, VIP paketlerini, oyuncu bakiyelerini ve promosyon kodlarını tek panelden yönetin.
        </p>
      </div>

      <div class="admin-global-actions">
        <a href="admin_servers.php" class="btn btn-outline btn-sm">
          <i class="fa-solid fa-server"></i> Sunucu Konsolu
        </a>
        <?php if ($isUnlocked): ?>
          <button class="btn btn-primary btn-sm" id="btnForceSync" title="Tüm açık Paper sunucularına RCON üzerinden anlık senkronizasyon komutu gönderir">
            <i class="fa-solid fa-rotate"></i> Tüm Sunucuları Eşitle
          </button>
          <button class="btn btn-outline btn-sm" id="btnLockPanel">
            <i class="fa-solid fa-lock"></i> Kilitle
          </button>
        <?php endif; ?>
      </div>
    </div>

    <!-- Üst Özet Kartları -->
    <div class="system-stats-grid">
      <div class="stat-card">
        <div class="stat-icon"><i class="fa-solid fa-layer-group"></i></div>
        <div class="stat-info">
          <span class="stat-label">Tanımlı Roller</span>
          <strong class="stat-value" id="statRolesCount"><?php echo count(gperm_get_roles()); ?> Grup</strong>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon"><i class="fa-solid fa-user-shield"></i></div>
        <div class="stat-info">
          <span class="stat-label">Yetkili / VIP Kayıtları</span>
          <strong class="stat-value" id="statUsersCount"><?php echo count(gperm_get_all_user_perms(false)); ?> Oyuncu</strong>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon"><i class="fa-solid fa-ticket"></i></div>
        <div class="stat-info">
          <span class="stat-label">Aktif Kupon Kodları</span>
          <strong class="stat-value" id="statCouponsCount"><?php echo count(gperm_get_coupons()); ?> Kod</strong>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon"><i class="fa-solid fa-bolt"></i></div>
        <div class="stat-info">
          <span class="stat-label">Senkron Revizyonu</span>
          <strong class="stat-value" id="statRevisionVal">#<?php echo intval($syncMeta['revision'] ?? 1); ?></strong>
        </div>
      </div>
    </div>

    <!-- PIN Kilit Ekranı -->
    <div id="pinLockOverlay" class="pin-lock-overlay <?php echo $isUnlocked ? 'hidden' : ''; ?>">
      <div class="pin-card">
        <div class="pin-icon"><i class="fa-solid fa-key"></i></div>
        <h2>Yönetici PIN Doğrulaması</h2>
        <p>Rolleri, izinleri ve oyuncu bakiyelerini düzenlemek için lütfen Yönetici PIN kodunuzu girin.</p>
        <form onsubmit="handlePermPinSubmit(event)">
          <div class="pin-input-wrap">
            <input type="password" id="adminPinInput" placeholder="PIN Kodu Girin" required autocomplete="off" autofocus>
            <button type="submit" class="btn btn-primary" id="btnPinSubmit">
              <i class="fa-solid fa-unlock"></i> Kilidi Aç
            </button>
          </div>
          <div id="pinErrorMsg" class="pin-error-msg"></div>
        </form>
        <span class="pin-hint"><i class="fa-solid fa-info-circle"></i> Varsayılan PIN: <code>Grizm2026!</code></span>
      </div>
    </div>

    <!-- ANA YÖNETİM PANELİ GÖVDESİ -->
    <div id="adminPanelContent" class="<?php echo !$isUnlocked ? 'blurred-content' : ''; ?>">

      <!-- Sekme Menüsü -->
      <div class="gp-tabs">
        <button class="gp-tab active" data-tab="roles"><i class="fa-solid fa-sitemap"></i> Roller & İzin Ağacı</button>
        <button class="gp-tab" data-tab="players"><i class="fa-solid fa-users-gear"></i> Oyuncu Yetki & Bakiye</button>
        <button class="gp-tab" data-tab="coupons"><i class="fa-solid fa-ticket"></i> Kupon & Hediye Kodları</button>
        <button class="gp-tab" data-tab="orders"><i class="fa-solid fa-receipt"></i> Satın Alımlar & Webhook</button>
      </div>

      <!-- ================================================================
           SEKME 1: ROLLER VE İZİNLER EDİTÖRÜ
           ================================================================ -->
      <div class="gp-pane active" id="pane-roles">
        <div class="gp-roles-layout">
          <!-- Sol: Rol Listesi -->
          <div class="gp-card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
              <h3 class="gp-card-title" style="margin: 0;">Gruplar (Ağırlık Sıralı)</h3>
              <button class="btn btn-primary btn-sm" onclick="startCreateNewRole()">
                <i class="fa-solid fa-plus"></i> Yeni Rol
              </button>
            </div>
            <div id="rolesSidebarList" class="gp-role-list"></div>
          </div>

          <!-- Sağ: Seçili Rol Düzenleyici -->
          <div class="gp-card">
            <form id="roleEditorForm" onsubmit="saveCurrentRole(event)">
              <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 18px; padding-bottom: 14px; border-bottom: 1px solid rgba(255,255,255,0.08);">
                <div>
                  <span style="font-family: var(--font-mono); font-size: 0.72rem; color: var(--text-muted); text-transform: uppercase;">Seçili Grup Düzenleyici</span>
                  <h3 id="editorHeadingTitle" style="color: #fff; font-size: 1.35rem; margin-top: 2px;">Rol Seçin</h3>
                </div>
                <div style="display: flex; gap: 8px;">
                  <button type="button" class="btn btn-outline btn-sm" id="btnDeleteRole" style="color: #ff6b6b; border-color: rgba(255,107,107,0.35);" onclick="deleteCurrentRole()">
                    <i class="fa-solid fa-trash"></i> Sil
                  </button>
                  <button type="submit" class="btn btn-primary btn-sm">
                    <i class="fa-solid fa-floppy-disk"></i> Kaydet & Eşitle
                  </button>
                </div>
              </div>

              <!-- Canlı Sohbet Önizlemesi -->
              <div class="gp-chat-preview-box">
                <span style="font-size: 0.7rem; font-family: var(--font-mono); color: #888; text-transform: uppercase;">Canlı Oyun İçi Sohbet Önizlemesi:</span>
                <div id="mcChatPreview" style="font-family: var(--font-mono); font-size: 0.94rem; margin-top: 6px; color: #fff;"></div>
              </div>

              <div class="gp-grid-3">
                <div class="form-group">
                  <label class="form-label">Rol Kimliği (ID)</label>
                  <input type="text" id="roleIdInput" class="form-input" placeholder="orn: mvip" required>
                </div>
                <div class="form-group">
                  <label class="form-label">Görünen Ad</label>
                  <input type="text" id="roleNameInput" class="form-input" placeholder="Örn: MVIP" required>
                </div>
                <div class="form-group">
                  <label class="form-label">Ağırlık / Öncelik (Weight)</label>
                  <input type="number" id="roleWeightInput" class="form-input" value="100" required>
                </div>
              </div>

              <div class="gp-grid-4">
                <div class="form-group">
                  <label class="form-label">Oyun İçi Prefix (& Kodlu)</label>
                  <input type="text" id="rolePrefixInput" class="form-input" placeholder="&b&l[VIP] &b" oninput="renderChatPreview()">
                </div>
                <div class="form-group">
                  <label class="form-label">Oyun İçi Suffix</label>
                  <input type="text" id="roleSuffixInput" class="form-input" placeholder=" &b❖" oninput="renderChatPreview()">
                </div>
                <div class="form-group">
                  <label class="form-label">Mesaj Rengi</label>
                  <input type="text" id="roleChatColorInput" class="form-input" value="&f" oninput="renderChatPreview()">
                </div>
                <div class="form-group">
                  <label class="form-label">Web Rozet Rengi (Hex)</label>
                  <input type="text" id="roleBadgeColorInput" class="form-input" value="#ffffff">
                </div>
              </div>

              <!-- Miras (Inheritance) -->
              <div class="form-group">
                <label class="form-label">Miras Alınan Roller (Alt grupların tüm izinlerini devralır)</label>
                <div id="roleInheritanceChecks" class="gp-check-pills"></div>
              </div>

              <!-- İzinler: Global + Sunucu Bazlı -->
              <div class="gp-grid-2">
                <div class="form-group">
                  <label class="form-label">Global İzinler (Her satıra 1 izin &bull; <code>*</code>, <code>essentials.*</code>, <code>-yasak.izin</code>)</label>
                  <textarea id="roleGlobalPerms" class="form-input gp-mono-area" rows="8" placeholder="essentials.fly&#10;essentials.heal"></textarea>
                </div>
                <div class="form-group">
                  <label class="form-label">Sunucuya Özel İzin / Engel Kuralları (Adil PvP vb.)</label>
                  <div class="gp-mini-srv-grid">
                    <div>
                      <small class="gp-srv-tag">LOBBY (Hub)</small>
                      <textarea id="roleSrvLobby" class="form-input gp-mono-area" rows="2" placeholder="essentials.fly"></textarea>
                    </div>
                    <div>
                      <small class="gp-srv-tag">SKYBLOCK (TekBlok)</small>
                      <textarea id="roleSrvSkyblock" class="form-input gp-mono-area" rows="2" placeholder="grizmoneblock.vip"></textarea>
                    </div>
                    <div>
                      <small class="gp-srv-tag">SMP (Towny)</small>
                      <textarea id="roleSrvSmp" class="form-input gp-mono-area" rows="2" placeholder="grizmtowny.vip"></textarea>
                    </div>
                    <div>
                      <small class="gp-srv-tag">PVP (Adil Arena Negasyonları)</small>
                      <textarea id="roleSrvPvp" class="form-input gp-mono-area" rows="2" placeholder="-essentials.fly&#10;-essentials.heal"></textarea>
                    </div>
                  </div>
                </div>
              </div>

              <!-- VIP Mağaza Ayarları -->
              <div class="gp-vip-settings-box">
                <div style="display: flex; align-items: center; gap: 20px; flex-wrap: wrap; margin-bottom: 12px;">
                  <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; color: #fff; font-weight: 600;">
                    <input type="checkbox" id="roleIsVipCheck" onchange="toggleVipFields()">
                    <span>VIP Mağazasında Satışa Açık Paket</span>
                  </label>
                  <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; color: var(--text-secondary); font-size: 0.85rem;">
                    <input type="checkbox" id="roleVipHighlightCheck">
                    <span>"EN POPÜLER" Olarak Öne Çıkar</span>
                  </label>
                  <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; color: var(--text-secondary); font-size: 0.85rem;">
                    <input type="checkbox" id="roleIsDefaultCheck">
                    <span>Varsayılan Oyuncu Rolü</span>
                  </label>
                </div>

                <div id="vipExtraFields" style="display: none;">
                  <div class="gp-grid-4">
                    <div class="form-group">
                      <label class="form-label">Mağaza Fiyatı (<?php echo STORE_CURRENCY; ?>)</label>
                      <input type="number" step="0.01" id="roleVipPriceInput" class="form-input" value="75">
                    </div>
                    <div class="form-group">
                      <label class="form-label">Paket Süresi (Gün)</label>
                      <input type="number" id="roleVipDaysInput" class="form-input" value="30">
                    </div>
                    <div class="form-group">
                      <label class="form-label">Tier Kodu</label>
                      <input type="text" id="roleVipTierInput" class="form-input" placeholder="iron / gold / diamond">
                    </div>
                    <div class="form-group">
                      <label class="form-label">Üst Rozet Yazısı</label>
                      <input type="text" id="roleVipBadgeInput" class="form-input" placeholder="EN POPÜLER">
                    </div>
                  </div>

                  <div class="gp-grid-2">
                    <div class="form-group" style="margin-bottom: 0;">
                      <label class="form-label">Mağaza Kartı Özellikleri (Her satıra 1 madde)</label>
                      <textarea id="roleVipPerksArea" class="form-input" rows="5"></textarea>
                    </div>
                    <div class="form-group" style="margin-bottom: 0;">
                      <label class="form-label">Satın Alım Anında Çalışacak Konsol Komutları (<code>sunucu:komut</code>, <code>{player}</code> destekli)</label>
                      <textarea id="roleVipCommandsArea" class="form-input gp-mono-area" rows="5" placeholder="skyblock:eco give {player} 50000&#10;smp:eco give {player} 50000"></textarea>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>

      <!-- ================================================================
           SEKME 2: OYUNCU YETKİ, SÜRELİ VIP VE CÜZDAN YÖNETİMİ
           ================================================================ -->
      <div class="gp-pane" id="pane-players">
        <div class="gp-grid-2" style="margin-bottom: 22px;">
          <!-- Hızlı Rol / VIP Tanımlama Kartı -->
          <div class="gp-card">
            <h3 class="gp-card-title"><i class="fa-solid fa-crown"></i> Oyuncuya Rol / Süreli VIP Tanımla</h3>
            <form onsubmit="handleAdminGrantRole(event)">
              <div class="gp-grid-3">
                <div class="form-group">
                  <label class="form-label">Minecraft Oyuncu Adı</label>
                  <input type="text" id="grantUsername" class="form-input" placeholder="Örn: yusufoyndberk" required>
                </div>
                <div class="form-group">
                  <label class="form-label">Verilecek Rol / VIP</label>
                  <select id="grantRoleSelect" class="form-input"></select>
                </div>
                <div class="form-group">
                  <label class="form-label">Süre (Gün, 0 = Kalıcı)</label>
                  <input type="number" id="grantDaysInput" class="form-input" value="30" min="0">
                </div>
              </div>
              <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
                <label style="display: flex; align-items: center; gap: 8px; font-size: 0.84rem; color: var(--text-secondary); cursor: pointer;">
                  <input type="checkbox" id="grantCelebrateCheck" checked>
                  <span>Oyun içinde VIP kutlama efekti & satın alım ödül komutlarını tetikle</span>
                </label>
                <button type="submit" class="btn btn-primary btn-sm">
                  <i class="fa-solid fa-bolt"></i> Yetkiyi Tanımla / Uzat
                </button>
              </div>
            </form>
          </div>

          <!-- Hızlı Cüzdan Bakiye Yönetimi Kartı -->
          <div class="gp-card">
            <h3 class="gp-card-title"><i class="fa-solid fa-wallet"></i> Oyuncu Cüzdan Bakiyesi Yönetimi (<?php echo STORE_CURRENCY; ?>)</h3>
            <form onsubmit="handleAdminCredits(event)">
              <div class="gp-grid-3">
                <div class="form-group">
                  <label class="form-label">Minecraft Oyuncu Adı</label>
                  <input type="text" id="creditUsername" class="form-input" placeholder="Örn: yusufoyndberk" required>
                </div>
                <div class="form-group">
                  <label class="form-label">İşlem Türü</label>
                  <select id="creditModeSelect" class="form-input">
                    <option value="add">Bakiye Ekle / Çıkar (+/-)</option>
                    <option value="set">Bakiyeyi Sabitle (=)</option>
                  </select>
                </div>
                <div class="form-group">
                  <label class="form-label">Tutar (<?php echo STORE_CURRENCY; ?>)</label>
                  <input type="number" step="0.01" id="creditAmountInput" class="form-input" value="100" required>
                </div>
              </div>
              <div style="display: flex; justify-content: flex-end;">
                <button type="submit" class="btn btn-primary btn-sm">
                  <i class="fa-solid fa-coins"></i> Bakiyeyi Güncelle
                </button>
              </div>
            </form>
          </div>
        </div>

        <!-- Kayıtlı Oyuncular Tablosu -->
        <div class="gp-card">
          <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 16px;">
            <h3 class="gp-card-title" style="margin: 0;"><i class="fa-solid fa-users"></i> Oyuncu Rol & Bakiye Listesi</h3>
            <input type="text" id="playerSearchInput" class="form-input" placeholder="Oyuncu veya e-posta ara..." style="max-width: 280px; padding: 8px 12px;" oninput="renderPlayersTable()">
          </div>
          <div style="overflow-x: auto;">
            <table class="gp-table">
              <thead>
                <tr>
                  <th>Oyuncu</th>
                  <th>Aktif Roller & Kalan Süre</th>
                  <th>Özel İzinler</th>
                  <th>Cüzdan</th>
                  <th>Hızlı İşlem</th>
                </tr>
              </thead>
              <tbody id="playersTableBody"></tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- ================================================================
           SEKME 3: KUPON & HEDİYE KODLARI
           ================================================================ -->
      <div class="gp-pane" id="pane-coupons">
        <div class="gp-grid-2">
          <div class="gp-card">
            <h3 class="gp-card-title"><i class="fa-solid fa-plus-circle"></i> Yeni Promosyon / Hediye Kodu Oluştur</h3>
            <form onsubmit="handleCreateCoupon(event)">
              <div class="gp-grid-2">
                <div class="form-group">
                  <label class="form-label">Kupon Kodu</label>
                  <input type="text" id="cpCode" class="form-input" placeholder="Örn: YAZ2026" style="text-transform: uppercase; font-family: var(--font-mono);" required>
                </div>
                <div class="form-group">
                  <label class="form-label">Ödül Tipi</label>
                  <select id="cpType" class="form-input" onchange="toggleCouponTypeFields()">
                    <option value="credit">Cüzdan Bakiyesi (<?php echo STORE_CURRENCY; ?>)</option>
                    <option value="vip">Doğrudan VIP / Rol Paketi</option>
                  </select>
                </div>
              </div>

              <div id="cpCreditWrap" class="form-group">
                <label class="form-label">Verilecek Bakiye Tutarı (<?php echo STORE_CURRENCY; ?>)</label>
                <input type="number" step="0.01" id="cpAmount" class="form-input" value="50">
              </div>

              <div id="cpVipWrap" class="gp-grid-2" style="display: none;">
                <div class="form-group">
                  <label class="form-label">Verilecek VIP / Rol</label>
                  <select id="cpRoleSelect" class="form-input"></select>
                </div>
                <div class="form-group">
                  <label class="form-label">VIP Süresi (Gün)</label>
                  <input type="number" id="cpVipDays" class="form-input" value="30">
                </div>
              </div>

              <div class="gp-grid-2">
                <div class="form-group">
                  <label class="form-label">Maksimum Kullanım Limiti (0 = Sınırsız)</label>
                  <input type="number" id="cpMaxUses" class="form-input" value="1" min="0">
                </div>
                <div class="form-group">
                  <label class="form-label">Son Kullanma Süresi (Gün, 0 = Süresiz)</label>
                  <input type="number" id="cpExpireDays" class="form-input" value="0" min="0">
                </div>
              </div>

              <button type="submit" class="btn btn-primary btn-sm" style="width: 100%;">
                <i class="fa-solid fa-ticket"></i> Kupon Kodunu Oluştur
              </button>
            </form>
          </div>

          <div class="gp-card">
            <h3 class="gp-card-title"><i class="fa-solid fa-tags"></i> Aktif Kupon Kodları</h3>
            <div style="overflow-x: auto;">
              <table class="gp-table">
                <thead>
                  <tr>
                    <th>Kod</th>
                    <th>Ödül</th>
                    <th>Kullanım</th>
                    <th>Sil</th>
                  </tr>
                </thead>
                <tbody id="couponsTableBody"></tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <!-- ================================================================
           SEKME 4: SİPARİŞ KAYITLARI & ÖDEME WEBHOOK ENTEGRASYONU
           ================================================================ -->
      <div class="gp-pane" id="pane-orders">
        <div class="gp-card" style="margin-bottom: 22px;">
          <h3 class="gp-card-title"><i class="fa-solid fa-plug"></i> Otomatik Ödeme Sağlayıcı Webhook Bağlantısı (Shopier / PayTR / İyzico)</h3>
          <p style="font-size: 0.86rem; color: var(--text-secondary); margin-bottom: 12px;">
            Harici sanal POS veya ödeme köprünüzden ödeme onaylandığında aşağıdaki uç noktaya <code>POST</code> isteği göndererek oyuncuya otomatik bakiye yükleyebilir veya doğrudan VIP tanımlayabilirsiniz:
          </p>
          <div class="gp-grid-2">
            <div style="background: rgba(0,0,0,0.45); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; padding: 12px; font-family: var(--font-mono); font-size: 0.78rem; color: #d4d4d8;">
              <div style="color: #888; margin-bottom: 4px;">Webhook URL:</div>
              <div style="color: #fff; word-break: break-all;"><?php echo htmlspecialchars(SITE_URL . '/api/perms.php?action=payment_webhook'); ?></div>
              <div style="color: #888; margin-top: 8px; margin-bottom: 4px;">Header (`X-Webhook-Secret`):</div>
              <div style="color: #fff;"><?php echo htmlspecialchars(PAYMENT_WEBHOOK_SECRET); ?></div>
            </div>
            <div style="background: rgba(0,0,0,0.45); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; padding: 12px; font-family: var(--font-mono); font-size: 0.75rem; color: #d4d4d8; white-space: pre-wrap;">{
  "order_id": "SHP-9001",
  "username": "OyuncuAdi",
  "mode": "vip",
  "role_id": "diamond-vip",
  "days": 30,
  "provider": "shopier"
}</div>
          </div>
        </div>

        <div class="gp-card">
          <h3 class="gp-card-title"><i class="fa-solid fa-clock-rotate-left"></i> Son Mağaza, VIP ve Bakiye İşlemleri</h3>
          <div style="overflow-x: auto;">
            <table class="gp-table">
              <thead>
                <tr>
                  <th>İşlem No</th>
                  <th>Oyuncu</th>
                  <th>Tür / Paket</th>
                  <th>Tutar</th>
                  <th>Kaynak & Not</th>
                  <th>Tarih</th>
                </tr>
              </thead>
              <tbody id="ordersTableBody"></tbody>
            </table>
          </div>
        </div>
      </div>

    </div>
  </div>
</main>

<!-- OYUNCU ÖZEL İZİN DÜZENLEME MODALI -->
<div class="modal-overlay" id="userPermsModal">
  <div class="modal-box" style="max-width: 520px;">
    <button class="modal-close" onclick="document.getElementById('userPermsModal').classList.remove('active')"><i class="fa-solid fa-xmark"></i></button>
    <div class="modal-header">
      <h3 id="uPermModalTitle">Oyuncu Özel İzinleri</h3>
      <p style="font-size: 0.82rem; color: var(--text-secondary);">Rollerden bağımsız olarak bu oyuncuya özel eklenen veya <code>-izin</code> ile engellenen izinler.</p>
    </div>
    <form onsubmit="saveUserCustomPerms(event)">
      <input type="hidden" id="uPermTargetUser">
      <div class="form-group">
        <label class="form-label">Global Özel İzinler (Her satıra 1 izin)</label>
        <textarea id="uPermGlobalArea" class="form-input gp-mono-area" rows="6" placeholder="essentials.fly&#10;-essentials.tpa"></textarea>
      </div>
      <button type="submit" class="btn btn-primary btn-sm" style="width: 100%;">
        <i class="fa-solid fa-floppy-disk"></i> Özel İzinleri Kaydet
      </button>
    </form>
  </div>
</div>

<style>
.admin-panel-wrapper { padding: 110px 0 80px 0; min-height: 90vh; position: relative; z-index: 2; }
.admin-header-row { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 28px; gap: 20px; flex-wrap: wrap; }
.admin-badge { display: inline-flex; align-items: center; gap: 8px; padding: 6px 14px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.16); border-radius: 999px; font-size: 0.74rem; font-weight: 700; letter-spacing: 1px; color: #fff; margin-bottom: 10px; }
.admin-title { font-family: var(--font-display); font-size: 2.1rem; font-weight: 800; color: #fff; margin-bottom: 6px; }
.admin-subtitle { color: var(--text-secondary); font-size: 0.92rem; max-width: 700px; line-height: 1.5; }
.admin-global-actions { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }

.system-stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 14px; margin-bottom: 28px; }
.stat-card { background: rgba(18,18,22,0.75); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 16px 18px; display: flex; align-items: center; gap: 14px; }
.stat-icon { width: 42px; height: 42px; border-radius: 10px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12); display: flex; align-items: center; justify-content: center; color: #fff; font-size: 1.1rem; }
.stat-info { display: flex; flex-direction: column; }
.stat-label { font-size: 0.72rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 3px; }
.stat-value { font-family: var(--font-mono); font-size: 1.05rem; color: #fff; }

.pin-lock-overlay { background: rgba(14,14,18,0.88); border: 1px solid rgba(255,255,255,0.15); border-radius: 18px; padding: 46px 24px; text-align: center; margin-bottom: 28px; }
.pin-lock-overlay.hidden { display: none; }
.blurred-content { filter: blur(5px); pointer-events: none; user-select: none; opacity: 0.45; }
.pin-card { max-width: 430px; margin: 0 auto; }
.pin-icon { width: 60px; height: 60px; margin: 0 auto 14px; border-radius: 50%; background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: #fff; }
.pin-input-wrap { display: flex; gap: 10px; margin: 18px 0 10px; }
.pin-input-wrap input { flex: 1; background: rgba(0,0,0,0.45); border: 1px solid rgba(255,255,255,0.2); border-radius: 10px; padding: 11px 14px; color: #fff; font-family: var(--font-mono); }
.pin-error-msg { color: #ff6b6b; font-size: 0.84rem; min-height: 20px; }
.pin-hint { font-size: 0.76rem; color: var(--text-muted); }

.gp-tabs { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 12px; }
.gp-tab { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); color: var(--text-secondary); padding: 10px 18px; border-radius: 10px; font-weight: 600; font-size: 0.88rem; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: all 0.18s ease; }
.gp-tab:hover { color: #fff; border-color: rgba(255,255,255,0.25); }
.gp-tab.active { background: #ffffff; color: #070708; border-color: #ffffff; }

.gp-pane { display: none; }
.gp-pane.active { display: block; }

.gp-roles-layout { display: grid; grid-template-columns: 300px 1fr; gap: 20px; align-items: start; }
@media (max-width: 980px) { .gp-roles-layout { grid-template-columns: 1fr; } }

.gp-card { background: rgba(15,15,19,0.9); border: 1px solid rgba(255,255,255,0.09); border-radius: 14px; padding: 22px; }
.gp-card-title { font-size: 1.05rem; font-weight: 700; color: #fff; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; }

.gp-role-list { display: flex; flex-direction: column; gap: 8px; }
.gp-role-item { padding: 11px 13px; border-radius: 10px; background: rgba(255,255,255,0.025); border: 1px solid rgba(255,255,255,0.07); cursor: pointer; display: flex; align-items: center; justify-content: space-between; transition: all 0.15s ease; }
.gp-role-item:hover { background: rgba(255,255,255,0.06); }
.gp-role-item.active { background: rgba(255,255,255,0.11); border-color: #ffffff; }

.gp-chat-preview-box { background: #09090c; border: 1px solid rgba(255,255,255,0.12); border-radius: 10px; padding: 12px 16px; margin-bottom: 18px; }

.gp-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
.gp-grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; }
.gp-grid-4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
@media (max-width: 780px) { .gp-grid-2, .gp-grid-3, .gp-grid-4 { grid-template-columns: 1fr; } }

.gp-mono-area { font-family: var(--font-mono); font-size: 0.8rem; line-height: 1.45; }
.gp-mini-srv-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.gp-srv-tag { display: block; font-family: var(--font-mono); font-size: 0.68rem; color: #a1a1aa; margin-bottom: 3px; }

.gp-check-pills { display: flex; flex-wrap: wrap; gap: 8px; }
.gp-check-pill { display: inline-flex; align-items: center; gap: 6px; padding: 6px 11px; border-radius: 8px; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.12); font-size: 0.8rem; color: #e4e4e7; cursor: pointer; }

.gp-vip-settings-box { margin-top: 12px; padding: 16px; border-radius: 12px; background: rgba(255,255,255,0.025); border: 1px solid rgba(255,255,255,0.09); }

.gp-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
.gp-table th { text-align: left; padding: 10px 8px; border-bottom: 1px solid rgba(255,255,255,0.1); font-family: var(--font-mono); font-size: 0.72rem; text-transform: uppercase; color: var(--text-muted); }
.gp-table td { padding: 11px 8px; border-bottom: 1px solid rgba(255,255,255,0.05); vertical-align: middle; }
.gp-role-pill { display: inline-flex; align-items: center; gap: 6px; padding: 3px 9px; border-radius: 999px; font-family: var(--font-mono); font-size: 0.72rem; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.22); margin: 2px 4px 2px 0; }
.gp-role-pill button { background: none; border: none; color: #ff6b6b; cursor: pointer; padding: 0 2px; font-size: 0.75rem; }
</style>

<script>
const GP_UNLOCKED = <?php echo $isUnlocked ? 'true' : 'false'; ?>;
let GP_STATE = { roles: [], users: [], coupons: [], orders: [], revision: 1 };
let SELECTED_ROLE_ID = null;

const MC_COLORS = {
  '0': '#000000', '1': '#0000AA', '2': '#00AA00', '3': '#00AAAA',
  '4': '#AA0000', '5': '#AA00AA', '6': '#FFAA00', '7': '#AAAAAA',
  '8': '#555555', '9': '#5555FF', 'a': '#55FF55', 'b': '#55FFFF',
  'c': '#FF5555', 'd': '#FF55FF', 'e': '#FFFF55', 'f': '#FFFFFF'
};

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.gp-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.gp-tab').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.gp-pane').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('pane-' + btn.dataset.tab).classList.add('active');
    });
  });

  document.getElementById('btnLockPanel')?.addEventListener('click', async () => {
    await fetch('api/perms.php?action=lock_panel');
    location.reload();
  });

  document.getElementById('btnForceSync')?.addEventListener('click', async () => {
    const res = await fetch('api/perms.php?action=admin_force_sync', { method: 'POST' });
    const data = await res.json();
    showToast(data.message || 'Senkronizasyon tetiklendi.');
    loadAdminOverview();
  });

  if (GP_UNLOCKED) {
    loadAdminOverview();
  }
});

async function handlePermPinSubmit(e) {
  e.preventDefault();
  const pin = document.getElementById('adminPinInput').value;
  const errEl = document.getElementById('pinErrorMsg');
  errEl.textContent = '';

  const res = await fetch('api/perms.php?action=unlock_panel', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ pin })
  });
  const data = await res.json();
  if (res.ok && data.status === 'success') {
    location.reload();
  } else {
    errEl.textContent = data.message || 'Hatalı PIN!';
  }
}

async function loadAdminOverview() {
  const res = await fetch('api/perms.php?action=admin_overview');
  const data = await res.json();
  if (!res.ok || data.status !== 'success') return;

  GP_STATE = data;
  document.getElementById('statRolesCount').textContent = `${data.roles.length} Grup`;
  document.getElementById('statUsersCount').textContent = `${data.users.length} Oyuncu`;
  document.getElementById('statCouponsCount').textContent = `${data.coupons.length} Kod`;
  document.getElementById('statRevisionVal').textContent = `#${data.revision}`;

  renderRolesSidebar();
  populateRoleDropdowns();
  if (!SELECTED_ROLE_ID && data.roles.length > 0) {
    selectRoleForEdit(data.roles[0].id);
  } else if (SELECTED_ROLE_ID) {
    const stillExists = data.roles.find(r => r.id === SELECTED_ROLE_ID);
    if (stillExists) selectRoleForEdit(SELECTED_ROLE_ID);
    else if (data.roles.length > 0) selectRoleForEdit(data.roles[0].id);
  }

  renderPlayersTable();
  renderCouponsTable();
  renderOrdersTable();
}

function escapeHtml(str) {
  return String(str ?? '').replace(/[&<>"']/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s]));
}

function mcFormatToHtml(raw) {
  let html = '';
  let color = '#ffffff';
  let bold = false;
  const text = String(raw || '');
  for (let i = 0; i < text.length; i++) {
    if ((text[i] === '&' || text[i] === '§') && i + 1 < text.length) {
      const code = text[i + 1].toLowerCase();
      if (MC_COLORS[code]) { color = MC_COLORS[code]; bold = false; i++; continue; }
      if (code === 'l') { bold = true; i++; continue; }
      if (code === 'r') { color = '#ffffff'; bold = false; i++; continue; }
    }
    html += `<span style="color:${color};${bold ? 'font-weight:800;' : ''}">${escapeHtml(text[i])}</span>`;
  }
  return html;
}

function renderChatPreview() {
  const prefix = document.getElementById('rolePrefixInput').value;
  const suffix = document.getElementById('roleSuffixInput').value;
  const chatColor = document.getElementById('roleChatColorInput').value || '&f';
  const sample = `${prefix}OyuncuAdi${suffix} &8» ${chatColor}Merhaba GrizmMC ailesi!`;
  document.getElementById('mcChatPreview').innerHTML = mcFormatToHtml(sample);
}

function renderRolesSidebar() {
  const listEl = document.getElementById('rolesSidebarList');
  listEl.innerHTML = GP_STATE.roles.map(r => `
    <div class="gp-role-item ${r.id === SELECTED_ROLE_ID ? 'active' : ''}" onclick="selectRoleForEdit('${escapeHtml(r.id)}')">
      <div>
        <div style="display:flex;align-items:center;gap:8px;">
          <span style="width:9px;height:9px;border-radius:50%;background:${escapeHtml(r.badge_color || '#fff')};"></span>
          <strong style="color:#fff;font-size:0.9rem;">${escapeHtml(r.name)}</strong>
          ${r.is_vip ? `<span style="font-size:0.65rem;padding:1px 6px;border-radius:99px;background:rgba(255,255,255,0.1);color:#fff;">${escapeHtml(r.vip_price)} ₺</span>` : ''}
        </div>
        <div style="font-family:var(--font-mono);font-size:0.72rem;color:#888;margin-top:2px;">ID: ${escapeHtml(r.id)} &bull; ${r.permissions.length} izin</div>
      </div>
      <span style="font-family:var(--font-mono);font-size:0.75rem;color:#aaa;">W:${r.weight}</span>
    </div>
  `).join('');
}

function populateRoleDropdowns() {
  const opts = GP_STATE.roles.map(r => `<option value="${escapeHtml(r.id)}">${escapeHtml(r.name)} (${escapeHtml(r.id)})</option>`).join('');
  document.getElementById('grantRoleSelect').innerHTML = opts;
  document.getElementById('cpRoleSelect').innerHTML = opts;
}

function selectRoleForEdit(roleId) {
  const role = GP_STATE.roles.find(r => r.id === roleId);
  if (!role) return;
  SELECTED_ROLE_ID = role.id;
  renderRolesSidebar();

  document.getElementById('editorHeadingTitle').textContent = `${role.name} (${role.id})`;
  const idInput = document.getElementById('roleIdInput');
  idInput.value = role.id;
  idInput.readOnly = true;

  document.getElementById('roleNameInput').value = role.name || '';
  document.getElementById('roleWeightInput').value = role.weight ?? 10;
  document.getElementById('rolePrefixInput').value = role.prefix || '';
  document.getElementById('roleSuffixInput').value = role.suffix || '';
  document.getElementById('roleChatColorInput').value = role.chat_color || '&f';
  document.getElementById('roleBadgeColorInput').value = role.badge_color || '#ffffff';

  document.getElementById('roleGlobalPerms').value = (role.permissions || []).join('\n');
  const sp = role.server_permissions || {};
  document.getElementById('roleSrvLobby').value = (sp.lobby || []).join('\n');
  document.getElementById('roleSrvSkyblock').value = (sp.skyblock || []).join('\n');
  document.getElementById('roleSrvSmp').value = (sp.smp || []).join('\n');
  document.getElementById('roleSrvPvp').value = (sp.pvp || []).join('\n');

  // Inheritance
  const inhSet = new Set(role.inheritance || []);
  document.getElementById('roleInheritanceChecks').innerHTML = GP_STATE.roles
    .filter(other => other.id !== role.id)
    .map(other => `
      <label class="gp-check-pill">
        <input type="checkbox" name="roleInh" value="${escapeHtml(other.id)}" ${inhSet.has(other.id) ? 'checked' : ''}>
        <span>${escapeHtml(other.name)}</span>
      </label>
    `).join('');

  document.getElementById('roleIsVipCheck').checked = !!role.is_vip;
  document.getElementById('roleVipHighlightCheck').checked = !!role.vip_highlight;
  document.getElementById('roleIsDefaultCheck').checked = !!role.is_default;
  document.getElementById('roleVipPriceInput').value = role.vip_price ?? 0;
  document.getElementById('roleVipDaysInput').value = role.vip_duration_days ?? 30;
  document.getElementById('roleVipTierInput').value = role.vip_tier || '';
  document.getElementById('roleVipBadgeInput').value = role.vip_badge || '';
  document.getElementById('roleVipPerksArea').value = (role.vip_perks || []).join('\n');
  document.getElementById('roleVipCommandsArea').value = (role.vip_reward_commands || [])
    .map(c => `${c.server || 'first'}:${c.command}`).join('\n');

  document.getElementById('btnDeleteRole').style.display = role.is_default ? 'none' : 'inline-flex';
  toggleVipFields();
  renderChatPreview();
}

function startCreateNewRole() {
  SELECTED_ROLE_ID = null;
  renderRolesSidebar();
  document.getElementById('editorHeadingTitle').textContent = 'Yeni Rol Oluştur';
  const idInput = document.getElementById('roleIdInput');
  idInput.value = '';
  idInput.readOnly = false;
  idInput.focus();

  document.getElementById('roleNameInput').value = '';
  document.getElementById('roleWeightInput').value = 50;
  document.getElementById('rolePrefixInput').value = '&7[YeniRol] &f';
  document.getElementById('roleSuffixInput').value = '';
  document.getElementById('roleChatColorInput').value = '&f';
  document.getElementById('roleBadgeColorInput').value = '#ffffff';
  document.getElementById('roleGlobalPerms').value = '';
  document.getElementById('roleSrvLobby').value = '';
  document.getElementById('roleSrvSkyblock').value = '';
  document.getElementById('roleSrvSmp').value = '';
  document.getElementById('roleSrvPvp').value = '';
  document.getElementById('roleIsVipCheck').checked = false;
  document.getElementById('roleVipHighlightCheck').checked = false;
  document.getElementById('roleIsDefaultCheck').checked = false;
  document.getElementById('roleVipPerksArea').value = '';
  document.getElementById('roleVipCommandsArea').value = '';
  document.getElementById('btnDeleteRole').style.display = 'none';

  document.getElementById('roleInheritanceChecks').innerHTML = GP_STATE.roles.map(other => `
    <label class="gp-check-pill">
      <input type="checkbox" name="roleInh" value="${escapeHtml(other.id)}" ${other.id === 'default' ? 'checked' : ''}>
      <span>${escapeHtml(other.name)}</span>
    </label>
  `).join('');

  toggleVipFields();
  renderChatPreview();
}

function toggleVipFields() {
  const show = document.getElementById('roleIsVipCheck').checked;
  document.getElementById('vipExtraFields').style.display = show ? 'block' : 'none';
}

async function saveCurrentRole(e) {
  e.preventDefault();
  const id = document.getElementById('roleIdInput').value.trim().toLowerCase();
  const inheritance = Array.from(document.querySelectorAll('input[name="roleInh"]:checked')).map(cb => cb.value);

  const rewardCommands = document.getElementById('roleVipCommandsArea').value
    .split(/\r?\n/)
    .map(l => l.trim())
    .filter(Boolean)
    .map(line => {
      const idx = line.indexOf(':');
      if (idx > 0) {
        return { server: line.slice(0, idx).trim(), command: line.slice(idx + 1).trim() };
      }
      return { server: 'first', command: line };
    });

  const payload = {
    id,
    name: document.getElementById('roleNameInput').value.trim(),
    weight: parseInt(document.getElementById('roleWeightInput').value || '10', 10),
    prefix: document.getElementById('rolePrefixInput').value,
    suffix: document.getElementById('roleSuffixInput').value,
    chat_color: document.getElementById('roleChatColorInput').value,
    badge_color: document.getElementById('roleBadgeColorInput').value,
    is_default: document.getElementById('roleIsDefaultCheck').checked,
    is_vip: document.getElementById('roleIsVipCheck').checked,
    vip_highlight: document.getElementById('roleVipHighlightCheck').checked,
    vip_price: parseFloat(document.getElementById('roleVipPriceInput').value || '0'),
    vip_duration_days: parseInt(document.getElementById('roleVipDaysInput').value || '30', 10),
    vip_tier: document.getElementById('roleVipTierInput').value.trim(),
    vip_badge: document.getElementById('roleVipBadgeInput').value.trim(),
    vip_perks: document.getElementById('roleVipPerksArea').value,
    vip_reward_commands: rewardCommands,
    inheritance,
    permissions: document.getElementById('roleGlobalPerms').value,
    server_permissions: {
      lobby: document.getElementById('roleSrvLobby').value,
      skyblock: document.getElementById('roleSrvSkyblock').value,
      smp: document.getElementById('roleSrvSmp').value,
      pvp: document.getElementById('roleSrvPvp').value
    }
  };

  const res = await fetch('api/perms.php?action=admin_save_role', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (res.ok && data.status === 'success') {
    SELECTED_ROLE_ID = data.role.id;
    showToast(data.message);
    loadAdminOverview();
  } else {
    showToast(data.message || 'Rol kaydedilemedi.');
  }
}

async function deleteCurrentRole() {
  if (!SELECTED_ROLE_ID) return;
  if (!confirm(`'${SELECTED_ROLE_ID}' rolünü kalıcı olarak silmek istediğinize emin misiniz?`)) return;

  const res = await fetch('api/perms.php?action=admin_delete_role', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id: SELECTED_ROLE_ID })
  });
  const data = await res.json();
  if (res.ok && data.status === 'success') {
    SELECTED_ROLE_ID = null;
    showToast('Rol silindi.');
    loadAdminOverview();
  } else {
    showToast(data.message || 'Rol silinemedi.');
  }
}

function formatExpiryShort(exp) {
  if (!exp || exp <= 0) return 'Kalıcı';
  const diff = exp - Math.floor(Date.now() / 1000);
  if (diff <= 0) return 'Doldu';
  const d = Math.floor(diff / 86400);
  const h = Math.floor((diff % 86400) / 3600);
  return d > 0 ? `${d}g ${h}s` : `${h}s`;
}

function renderPlayersTable() {
  const q = (document.getElementById('playerSearchInput')?.value || '').trim().toLowerCase();
  const roleMap = Object.fromEntries(GP_STATE.roles.map(r => [r.id, r]));
  const filtered = GP_STATE.users.filter(u => {
    if (!q) return true;
    return (u.username || '').toLowerCase().includes(q) || (u.email || '').toLowerCase().includes(q);
  });

  const tbody = document.getElementById('playersTableBody');
  if (filtered.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" style="color:#888;text-align:center;padding:20px;">Eşleşen oyuncu bulunamadı.</td></tr>';
    return;
  }

  tbody.innerHTML = filtered.map(u => {
    const rolesHtml = (u.roles && u.roles.length > 0)
      ? u.roles.map(ass => {
          const rObj = roleMap[ass.role_id] || { name: ass.role_id, badge_color: '#fff' };
          return `<span class="gp-role-pill" style="border-color:${escapeHtml(rObj.badge_color || '#fff')};color:#fff;">
            ${escapeHtml(rObj.name)} <small style="color:#aaa;">(${formatExpiryShort(ass.expires_at)})</small>
            <button type="button" title="Rolü Kaldır" onclick="revokeUserRole('${escapeHtml(u.username)}','${escapeHtml(ass.role_id)}')">&times;</button>
          </span>`;
        }).join('')
      : '<span style="color:#777;font-family:var(--font-mono);font-size:0.76rem;">Oyuncu (Varsayılan)</span>';

    const customPermCount = (u.permissions || []).length;
    return `
      <tr>
        <td>
          <div style="display:flex;align-items:center;gap:10px;">
            <img src="https://mc-heads.net/avatar/${encodeURIComponent(u.username)}/28" style="width:28px;height:28px;border-radius:4px;image-rendering:pixelated;" onerror="this.src='https://mc-heads.net/avatar/Steve/28';">
            <div>
              <strong style="color:#fff;">${escapeHtml(u.username)}</strong>
              <div style="font-size:0.74rem;color:#888;">${escapeHtml(u.email || '')}</div>
            </div>
          </div>
        </td>
        <td>${rolesHtml}</td>
        <td style="font-family:var(--font-mono);font-size:0.78rem;color:#ccc;">${customPermCount} özel izin</td>
        <td style="font-family:var(--font-mono);font-weight:700;color:#fff;">${Number(u.credits || 0).toFixed(2)} ₺</td>
        <td>
          <div style="display:flex;gap:6px;flex-wrap:wrap;">
            <button class="btn btn-ghost btn-sm" style="padding:5px 10px;font-size:0.75rem;" onclick="prefillPlayerForms('${escapeHtml(u.username)}')">Seç</button>
            <button class="btn btn-outline btn-sm" style="padding:5px 10px;font-size:0.75rem;" onclick="openUserPermsModal('${escapeHtml(u.username)}')">İzinler</button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

function prefillPlayerForms(username) {
  document.getElementById('grantUsername').value = username;
  document.getElementById('creditUsername').value = username;
  window.scrollTo({ top: 240, behavior: 'smooth' });
}

async function handleAdminGrantRole(e) {
  e.preventDefault();
  const payload = {
    username: document.getElementById('grantUsername').value.trim(),
    role_id: document.getElementById('grantRoleSelect').value,
    duration_days: parseInt(document.getElementById('grantDaysInput').value || '0', 10),
    celebrate: document.getElementById('grantCelebrateCheck').checked
  };
  const res = await fetch('api/perms.php?action=admin_grant_role', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  showToast(data.message || 'İşlem tamamlandı.');
  if (res.ok) loadAdminOverview();
}

async function revokeUserRole(username, roleId) {
  if (!confirm(`${username} oyuncusundan '${roleId}' rolünü kaldırmak istiyor musunuz?`)) return;
  const res = await fetch('api/perms.php?action=admin_revoke_role', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, role_id: roleId })
  });
  const data = await res.json();
  showToast(data.message || 'Rol kaldırıldı.');
  if (res.ok) loadAdminOverview();
}

async function handleAdminCredits(e) {
  e.preventDefault();
  const payload = {
    username: document.getElementById('creditUsername').value.trim(),
    mode: document.getElementById('creditModeSelect').value,
    amount: parseFloat(document.getElementById('creditAmountInput').value || '0')
  };
  const res = await fetch('api/perms.php?action=admin_adjust_credits', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  showToast(data.message || 'Bakiye güncellendi.');
  if (res.ok) loadAdminOverview();
}

function openUserPermsModal(username) {
  const user = GP_STATE.users.find(u => u.username.toLowerCase() === username.toLowerCase());
  document.getElementById('uPermTargetUser').value = username;
  document.getElementById('uPermModalTitle').textContent = `${username} - Özel İzinler`;
  document.getElementById('uPermGlobalArea').value = (user?.permissions || []).join('\n');
  document.getElementById('userPermsModal').classList.add('active');
}

async function saveUserCustomPerms(e) {
  e.preventDefault();
  const username = document.getElementById('uPermTargetUser').value;
  const permissions = document.getElementById('uPermGlobalArea').value;
  const res = await fetch('api/perms.php?action=admin_save_user_perms', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, permissions })
  });
  const data = await res.json();
  showToast(data.message || 'Kaydedildi.');
  document.getElementById('userPermsModal').classList.remove('active');
  if (res.ok) loadAdminOverview();
}

function toggleCouponTypeFields() {
  const isVip = document.getElementById('cpType').value === 'vip';
  document.getElementById('cpCreditWrap').style.display = isVip ? 'none' : 'block';
  document.getElementById('cpVipWrap').style.display = isVip ? 'grid' : 'none';
}

async function handleCreateCoupon(e) {
  e.preventDefault();
  const payload = {
    code: document.getElementById('cpCode').value.trim(),
    type: document.getElementById('cpType').value,
    amount: parseFloat(document.getElementById('cpAmount').value || '0'),
    role_id: document.getElementById('cpRoleSelect').value,
    duration_days: parseInt(document.getElementById('cpVipDays').value || '30', 10),
    max_uses: parseInt(document.getElementById('cpMaxUses').value || '1', 10),
    expire_days: parseInt(document.getElementById('cpExpireDays').value || '0', 10)
  };
  const res = await fetch('api/perms.php?action=admin_create_coupon', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  showToast(data.message || 'Kupon oluşturuldu.');
  if (res.ok) {
    document.getElementById('cpCode').value = '';
    loadAdminOverview();
  }
}

async function deleteCoupon(code) {
  if (!confirm(`'${code}' kupon kodunu silmek istiyor musunuz?`)) return;
  const res = await fetch('api/perms.php?action=admin_delete_coupon', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ code })
  });
  const data = await res.json();
  showToast(data.message || 'Silindi.');
  if (res.ok) loadAdminOverview();
}

function renderCouponsTable() {
  const tbody = document.getElementById('couponsTableBody');
  if (!GP_STATE.coupons.length) {
    tbody.innerHTML = '<tr><td colspan="4" style="color:#888;text-align:center;">Aktif kupon bulunmuyor.</td></tr>';
    return;
  }
  tbody.innerHTML = GP_STATE.coupons.map(c => {
    const used = (c.used_by || []).length;
    const limit = c.max_uses > 0 ? `${used} / ${c.max_uses}` : `${used} / ∞`;
    const reward = c.type === 'vip'
      ? `<span style="color:#fff;">${escapeHtml(c.role_id)} (${c.duration_days}g)</span>`
      : `<span style="color:#fff;font-family:var(--font-mono);">+${Number(c.amount).toFixed(2)} ₺</span>`;
    return `
      <tr>
        <td style="font-family:var(--font-mono);font-weight:700;color:#fff;">${escapeHtml(c.code)}</td>
        <td>${reward}</td>
        <td style="font-family:var(--font-mono);color:#aaa;">${limit}</td>
        <td>
          <button class="btn btn-outline btn-sm" style="color:#ff6b6b;border-color:rgba(255,107,107,0.3);padding:4px 9px;" onclick="deleteCoupon('${escapeHtml(c.code)}')">
            <i class="fa-solid fa-trash"></i>
          </button>
        </td>
      </tr>
    `;
  }).join('');
}

function renderOrdersTable() {
  const tbody = document.getElementById('ordersTableBody');
  if (!GP_STATE.orders.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="color:#888;text-align:center;padding:18px;">Henüz kayıtlı işlem yok.</td></tr>';
    return;
  }
  tbody.innerHTML = GP_STATE.orders.map(o => {
    const dt = new Date((o.created_at || 0) * 1000).toLocaleString('tr-TR');
    return `
      <tr>
        <td style="font-family:var(--font-mono);color:#aaa;">${escapeHtml(o.order_id)}</td>
        <td><strong style="color:#fff;">${escapeHtml(o.username)}</strong></td>
        <td style="color:#fff;">${escapeHtml(o.role_name || o.type)}</td>
        <td style="font-family:var(--font-mono);color:#fff;">${Number(o.amount || 0) > 0 ? Number(o.amount).toFixed(2) + ' ₺' : '-'}</td>
        <td style="color:var(--text-secondary);">${escapeHtml(o.provider)} &bull; ${escapeHtml(o.note || '')}</td>
        <td style="font-family:var(--font-mono);color:#888;">${escapeHtml(dt)}</td>
      </tr>
    `;
  }).join('');
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

