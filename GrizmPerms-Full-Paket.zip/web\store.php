<?php
$pageTitle = "VIP Mağazası";
$activePage = "store";
require_once __DIR__ . '/config.php';

$isLogged = is_logged_in();
$currentMcName = $isLogged ? get_auth_username() : '';
$storeUserRecord = $isLogged ? gperm_get_user($currentMcName) : null;
$storeCredits = floatval($storeUserRecord['credits'] ?? 0);
$storePrimary = $isLogged ? gperm_get_user_primary_role($currentMcName)['role'] : null;
$storeActiveVip = $isLogged ? gperm_get_user_active_vip($currentMcName) : null;

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<!-- MAĞAZA HERO -->
<section class="store-hero">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">Ayrıcalıklar & Destek</span>
      <h1 class="section-title">VIP MAĞAZASI</h1>
      <p class="section-desc">
        Sunucu masraflarımıza destek olarak özel komutlar, kozmetikler ve oyun içi ayrıcalıklar elde edin. Tüm alımlar <strong>GrizmPerms</strong> altyapısıyla tüm sunucularda saniyeler içinde otomatik teslim edilir.
      </p>
    </div>

    <!-- KULLANICI CÜZDAN, AKTİF RÜTBE VE KUPON ÇUBUĞU -->
    <div class="feature-box" style="padding: 24px 28px; margin-bottom: 36px; border: 1px solid var(--border-medium); background: linear-gradient(180deg, rgba(255,255,255,0.035) 0%, rgba(14,14,17,0.95) 100%);">
      <?php if ($isLogged): ?>
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 20px;">
          <!-- Sol: Oyuncu & Aktif Rütbe Bilgisi -->
          <div style="display: flex; align-items: center; gap: 16px;">
            <img
              src="https://mc-heads.net/avatar/<?php echo urlencode($currentMcName); ?>/48"
              alt="Avatar"
              style="width: 48px; height: 48px; border-radius: var(--radius-sm); border: 1px solid var(--border-medium); image-rendering: pixelated;"
              onerror="this.src='https://mc-heads.net/avatar/Steve/48';"
            >
            <div>
              <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <strong style="color: #fff; font-size: 1.05rem;"><?php echo htmlspecialchars($currentMcName); ?></strong>
                <?php if ($storePrimary): ?>
                  <span id="store-active-role-badge" style="font-family: var(--font-mono); font-size: 0.72rem; padding: 2px 9px; border-radius: 999px; border: 1px solid <?php echo htmlspecialchars($storePrimary['badge_color'] ?? '#fff'); ?>; color: <?php echo htmlspecialchars($storePrimary['badge_color'] ?? '#fff'); ?>; background: rgba(255,255,255,0.05);">
                    <?php echo htmlspecialchars($storePrimary['name']); ?>
                  </span>
                <?php endif; ?>
              </div>
              <div id="store-vip-status-line" style="font-size: 0.82rem; color: var(--text-secondary); margin-top: 4px;">
                <?php if ($storeActiveVip): ?>
                  <i class="fa-solid fa-crown" style="color: #facc15;"></i>
                  Aktif VIP: <strong style="color: #fff;"><?php echo htmlspecialchars($storeActiveVip['role']['name']); ?></strong>
                  &bull; Kalan Süre: <span style="font-family: var(--font-mono); color: #fff;"><?php echo htmlspecialchars(gperm_format_remaining($storeActiveVip['expires_at'])); ?></span>
                <?php else: ?>
                  <span>Aktif süreli VIP üyeliğiniz bulunmuyor. Aşağıdan dilediğiniz paketi anında aktifleştirebilirsiniz.</span>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <!-- Orta: Cüzdan Bakiyesi -->
          <div style="display: flex; align-items: center; gap: 18px; flex-wrap: wrap;">
            <div style="padding: 10px 18px; border-radius: var(--radius-sm); background: rgba(255,255,255,0.04); border: 1px solid var(--border-subtle); text-align: right;">
              <div style="font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.08em; color: var(--text-muted); font-family: var(--font-mono);">Cüzdan Bakiyesi</div>
              <div style="font-size: 1.3rem; font-weight: 800; color: #fff; font-family: var(--font-mono);">
                <span data-wallet-balance><?php echo number_format($storeCredits, 2, '.', ''); ?></span> <?php echo STORE_CURRENCY; ?>
              </div>
            </div>

            <!-- Sağ: Hızlı Kupon / Bakiye Kodu Formu -->
            <form id="store-coupon-form" style="display: flex; align-items: center; gap: 8px;">
              <input
                type="text"
                id="store-coupon-input"
                class="form-input"
                placeholder="Hediye / Bakiye Kodu"
                style="width: 185px; padding: 10px 12px; font-family: var(--font-mono); font-size: 0.82rem; text-transform: uppercase;"
                autocomplete="off"
              >
              <button type="submit" class="btn btn-ghost btn-sm" style="padding: 10px 14px; white-space: nowrap;">
                <i class="fa-solid fa-ticket"></i>
                <span>Kodu Kullan</span>
              </button>
            </form>
          </div>
        </div>
      <?php else: ?>
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px;">
          <div>
            <strong style="color: #fff; font-size: 1rem;"><i class="fa-solid fa-wallet"></i> Otomatik VIP Teslimatı İçin Giriş Yapın</strong>
            <p style="font-size: 0.85rem; color: var(--text-secondary); margin: 4px 0 0;">
              GrizmID hesabınızla giriş yaparak cüzdan bakiyenizi görüntüleyebilir, kupon kodu kullanabilir ve tek tıkla VIP satın alabilirsiniz.
            </p>
          </div>
          <a href="login.php" class="btn btn-primary btn-sm">
            <i class="fa-solid fa-user-lock"></i>
            <span>Giriş Yap</span>
          </a>
        </div>
      <?php endif; ?>
    </div>

    <!-- VIP PAKETLERİ GRID -->
    <div class="vip-grid">
      <?php foreach ($VIP_PACKAGES as $vip):
        $isCurrentVip = ($storeActiveVip && strtolower($storeActiveVip['role']['id']) === strtolower($vip['id']));
      ?>
        <div class="vip-card <?php echo !empty($vip['highlight']) ? 'featured' : ''; ?>">
          <?php if (!empty($vip['highlight'])): ?>
            <div class="featured-ribbon"><?php echo htmlspecialchars($vip['badge']); ?></div>
          <?php endif; ?>

          <div>
            <div class="vip-header">
              <span class="vip-tier-badge"><?php echo htmlspecialchars($vip['tier']); ?> tier</span>
              <h3 class="vip-name"><?php echo htmlspecialchars($vip['name']); ?></h3>
              <div class="vip-pricing">
                <span class="vip-currency"><?php echo STORE_CURRENCY; ?></span>
                <span class="vip-amount"><?php echo htmlspecialchars($vip['price']); ?></span>
                <span class="vip-period">/ <?php echo htmlspecialchars($vip['duration']); ?></span>
              </div>
            </div>

            <ul class="vip-perks-list">
              <?php foreach ($vip['perks'] as $perk): ?>
                <li>
                  <i class="fa-solid fa-check"></i>
                  <span><?php echo htmlspecialchars($perk); ?></span>
                </li>
              <?php endforeach; ?>
            </ul>
          </div>

          <button 
            class="btn <?php echo !empty($vip['highlight']) ? 'btn-primary' : 'btn-ghost'; ?> btn-sm"
            style="width: 100%;"
            data-buy-vip="true"
            data-role-id="<?php echo htmlspecialchars($vip['id']); ?>"
            data-package-name="<?php echo htmlspecialchars($vip['name']); ?>"
            data-package-price="<?php echo htmlspecialchars($vip['price'] . ' ' . STORE_CURRENCY); ?>"
            data-package-price-num="<?php echo htmlspecialchars($vip['price_num'] ?? floatval($vip['price'])); ?>"
            data-package-duration="<?php echo htmlspecialchars($vip['duration']); ?>"
          >
            <i class="fa-solid <?php echo $isCurrentVip ? 'fa-clock-rotate-left' : 'fa-cart-shopping'; ?>"></i>
            <span><?php echo $isCurrentVip ? 'Süreyi Uzat (+30 Gün)' : 'Satın Al'; ?></span>
          </button>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- GÜVENLİ ÖDEME BİLGİSİ -->
    <div class="features-grid" style="margin-top: 50px;">
      <div class="feature-box">
        <div class="feature-box-icon"><i class="fa-solid fa-bolt"></i></div>
        <h4 class="feature-box-title">Anında Otomatik Teslimat</h4>
        <p class="feature-box-desc">Satın aldığınız anda <strong>GrizmPerms</strong> tüm sunucularda (Lobi, TekBlok, Towny SMP, PvP) rütbenizi, izinlerinizi ve ödül paranızı otomatik tanımlar.</p>
      </div>

      <div class="feature-box">
        <div class="feature-box-icon"><i class="fa-solid fa-gift"></i></div>
        <h4 class="feature-box-title">Süre Uzatma & Arkadaşa Hediye</h4>
        <p class="feature-box-desc">Mevcut VIP paketinizin süresi bitmeden yeniden alırsanız kalan sürenizin üzerine eklenir. Dilerseniz başka bir oyuncuya hediye edebilirsiniz.</p>
      </div>

      <div class="feature-box">
        <div class="feature-box-icon"><i class="fa-solid fa-headset"></i></div>
        <h4 class="feature-box-title">Bakiye Yükleme & Canlı Destek</h4>
        <p class="feature-box-desc">Kart, Havale/EFT veya hediye kodları ile cüzdanınıza bakiye yükleyebilir; her türlü soruda <a href="support.php" style="color: #fff; text-decoration: underline;">Destek Merkezi</a> üzerinden bize ulaşabilirsiniz.</p>
      </div>
    </div>
  </div>
</section>

<!-- SATIN ALIM MODAL PENCERESİ -->
<div class="modal-overlay" id="checkout-modal" data-logged-in="<?php echo $isLogged ? '1' : '0'; ?>" data-user-credits="<?php echo htmlspecialchars(number_format($storeCredits, 2, '.', '')); ?>">
  <div class="modal-box" style="max-width: 480px;">
    <button class="modal-close" aria-label="Kapat"><i class="fa-solid fa-xmark"></i></button>

    <div class="modal-header">
      <span style="font-family: var(--font-mono); font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--text-muted);">GrizmPerms Otomatik Teslimat</span>
      <h3 id="modal-package-title" style="margin-top: 4px;">VIP Üyelik</h3>
      <p>Paket Tutarı: <strong id="modal-package-price" style="color: #fff;">0 ₺</strong> <span id="modal-package-duration" style="color: var(--text-muted); font-size: 0.85rem;">/ 30 Gün</span></p>
    </div>

    <?php if (!$isLogged): ?>
      <div style="padding: 20px; border-radius: var(--radius-sm); background: rgba(255,255,255,0.04); border: 1px solid var(--border-medium); text-align: center; margin-bottom: 16px;">
        <i class="fa-solid fa-user-shield" style="font-size: 2rem; color: #fff; margin-bottom: 10px;"></i>
        <h4 style="color: #fff; margin-bottom: 6px;">GrizmID Oturumu Gerekli</h4>
        <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 16px;">
          Güvenliğiniz ve oyun içi anında teslimat için lütfen önce hesabınızla giriş yapın.
        </p>
        <a href="login.php" class="btn btn-primary" style="width: 100%;">
          <i class="fa-solid fa-right-to-bracket"></i>
          <span>Giriş Yap ve Satın Al</span>
        </a>
      </div>
    <?php else: ?>
      <form id="checkout-form">
        <input type="hidden" id="checkout-role-id" value="">

        <div class="form-group">
          <label for="mc-username" class="form-label">Teslim Edilecek Minecraft Oyuncu Adı</label>
          <input type="text" id="mc-username" class="form-input" placeholder="Örn: ProGamer_34" value="<?php echo htmlspecialchars($currentMcName); ?>" required autocomplete="off">
          <small style="color: #888; font-size: 0.76rem; display: block; margin-top: 6px;">
            <i class="fa-solid fa-circle-check" style="color: #fff;"></i> Kendi hesabınız otomatik yazıldı. Arkadaşınıza <strong>hediye etmek</strong> isterseniz onun kullanıcı adını yazabilirsiniz.
          </small>
        </div>

        <!-- Cüzdan Hesap Özeti -->
        <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 14px 16px; margin-bottom: 16px; font-size: 0.86rem;">
          <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
            <span style="color: var(--text-secondary);">Mevcut Cüzdan Bakiyeniz:</span>
            <strong style="font-family: var(--font-mono); color: #fff;"><span data-wallet-balance><?php echo number_format($storeCredits, 2, '.', ''); ?></span> <?php echo STORE_CURRENCY; ?></strong>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
            <span style="color: var(--text-secondary);">Paket Ücreti:</span>
            <strong style="font-family: var(--font-mono); color: #fff;" id="checkout-summary-price">0.00 <?php echo STORE_CURRENCY; ?></strong>
          </div>
          <div style="border-top: 1px solid var(--border-subtle); padding-top: 8px; margin-top: 6px; display: flex; justify-content: space-between; align-items: center;">
            <span id="checkout-after-label" style="color: var(--text-secondary);">İşlem Sonrası Bakiye:</span>
            <strong id="checkout-after-balance" style="font-family: var(--font-mono); color: #fff;">0.00 <?php echo STORE_CURRENCY; ?></strong>
          </div>
        </div>

        <div id="checkout-insufficient-box" style="display: none; background: rgba(255, 85, 85, 0.08); border: 1px solid rgba(255, 85, 85, 0.35); border-radius: var(--radius-sm); padding: 12px 14px; margin-bottom: 14px; font-size: 0.8rem; color: #fca5a5; line-height: 1.45;">
          <i class="fa-solid fa-triangle-exclamation"></i>
          <strong>Cüzdan bakiyeniz bu paket için yetersiz.</strong> Mağaza üst barından hediye/bakiye kodu kullanabilir veya <a href="support.php?tab=new" style="color: #fff; text-decoration: underline;">Destek & Ödeme Talebi</a> / Discord üzerinden anında bakiye yükleyebilirsiniz.
        </div>

        <div id="checkout-feedback-msg" style="display: none; padding: 12px 14px; border-radius: var(--radius-sm); margin-bottom: 14px; font-size: 0.84rem;"></div>

        <button type="submit" id="checkout-submit-btn" class="btn btn-primary" style="width: 100%; margin-top: 4px;">
          <i class="fa-solid fa-bolt"></i>
          <span>Cüzdan ile Anında Satın Al</span>
        </button>

        <div style="font-size: 0.72rem; color: #777782; text-align: center; margin-top: 14px; line-height: 1.4;">
          <i class="fa-solid fa-circle-info"></i> Onayladığınız anda tutar cüzdanınızdan düşülür ve VIP rütbeniz oyun içinde otomatik tanımlanır.
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
